#' performs all functions all together
#'
#' This function is able to calculate tollerance indices and depict all related graphs accordingly.
#' @param perform_all data should be provided.
#' @return all out required.
#' @export
#' @examples
#' perform_all()
#' 
#' 
perform_all <- function(){

#This section loads the packages that are used for analysis
library(readxl) #for reading excel files
require(gplots) #drawing instrument for related packages 
require(ggplot2) #drawing instrument for related packages
require(factoextra) #calculating principal component analysis based on indices
require(ggcorrplot) #for drawing correlation plot 
require(scatterplot3d) #for drawing 3D plots 

#This section is for loading excel sheet containing data
df <- read_excel(file.choose(), sheet = 1); df <- df[, 1:4]  
colnames(df) <- c("genotype", "replications", "p", "s")
df <- df[order(df$genotype),]  
#View(df)

#This section calculates the mean yield of each genotype and sort them accordingly
attach(df) 
dt <- aggregate(df, by=list(genotype), FUN=mean, na.rm=TRUE)
dt <- dt[order(dt$genotype),]
dt <- as.data.frame(dt[, -c(1, 3)])
#View(dt)

m.p <- mean(dt$p); m.s <- mean(dt$s) #Calculates total mean yield in each condition

#This section calculated the tollerance indices based on their formulas
SSI <- (1-(dt$s/dt$p))/(1-(dt$s/m.p))
SSI <- as.matrix(SSI); colnames(SSI)<- "SSI"

YR <- 1-(dt$s/dt$p)
YR <- as.matrix(YR); colnames(YR)<- "YR"

TOL <- dt$p-dt$s
TOL <- as.matrix(TOL); colnames(TOL)<- "TOL"

MP <- (dt$s+dt$p)/2
MP <- as.matrix(MP); colnames(MP)<- "MP"

YI <- dt$s/m.s
YI <- as.matrix(YI); colnames(YI)<- "YI"

YSI <- dt$s/dt$p
YSI <- as.matrix(YSI); colnames(YSI)<- "YSI"

GMP <- (dt$s*dt$p)^0.5
GMP <- as.matrix(GMP); colnames(GMP)<- "GMP"

HARM <- (2*dt$p*dt$s)/(dt$p+dt$s)
HARM <- as.matrix(HARM); colnames(HARM)<- "HARM"

STI <- (dt$p*dt$s)/(dt$p^2)
STI <- as.matrix(STI); colnames(STI)<- "STI"

MpSTI <- ((dt$p*2)/(m.p*2))*((dt$p*dt$s)/(dt$p^2))
MpSTI <- as.matrix(MpSTI); colnames(MpSTI)<- "MpSTI"

MsSTI <- ((dt$s*2)/(m.s*2))*((dt$p*dt$s)/(dt$p^2))
MsSTI <- as.matrix(MsSTI); colnames(MsSTI)<- "MsSTI"

SDI <- (dt$p-dt$s)/dt$p
SDI <- as.matrix(SDI); colnames(SDI)<- "SDI"

SSPI <- ((dt$p-dt$s)/(2*m.p))*100
SSPI <- as.matrix(SSPI); colnames(SSPI)<- "SSPI"

RDI <- (dt$s/dt$p)/(m.s/m.p)
RDI <- as.matrix(RDI); colnames(RDI)<- "RDI"

DI <- ((dt$s/dt$p)/m.s)*dt$s
DI <- as.matrix(DI); colnames(DI)<- "DI"

ATI <- ((dt$p-dt$s)/(m.p-m.s))*((dt$p*dt$s)^0.5)
ATI <- as.matrix(ATI); colnames(ATI)<- "ATI"

GM <- (dt$p*dt$s)/(dt$p-dt$s)
GM <- as.matrix(GM); colnames(GM)<- "GM"


#Following lines (87-93) provides a data table named "i" containing all calculated indices
i <- cbind(dt$p, dt$s, YR, SSI, TOL, STI, MpSTI, MsSTI, ATI, YI, 
           YSI, MP, GMP, HARM, GM, SDI, SSPI, RDI, DI)
colnames(i) <- c('y.nrm', 'y.str', 'YR', 'SSI', 'TOL', 'STI', 'MpSTI',
                 'MsSTI','ATI', 'YI', 'YSI','MP', 'GMP', 'HARM', 'GM',
                 'SDI', 'SSPI', 'RDI', 'DI')
rownames(i) <- dt[,1]; i <- as.data.frame(i)
View(i)


#Following code would perform correlation coefficient analysis and store the results
#in a data table named "cor" as well as drawing correlation plot
corr <- round(cor(i), 2); pc <- cor_pmat(i); View(corr)

ggcorrplot(corr)
#Correlation plot with just colors and no figure or indicator of significance

ggcorrplot(corr, method = "square",lab = FALSE, digit=2, p.mat = pc, 
           sig.level =0.05, colors = c('blue', 'white', 'red')) 
#The above two lines indicates not significant correlaitons by cross sign (*)

ggcorrplot(corr, method = "square",lab = TRUE, digit=1, p.mat = pc, 
           sig.level =0.05, colors = c('blue', 'white', 'red')) 
#shows the values of correlation between each pair of indices and indicated 
#the significance level by cross sign (*)


#Following code section performs scater plot for yield in stress vs. normal
with(i, plot(y.nrm, y.str, main="Yield: stress vs. normal",
             xlab="Yield in normal condition", 
             ylab="Yield in stress condition", pch=15, col="red"))
abline(a = mean(i$y.str), b = 0, v = mean(i$y.nrm), col="blue")


#Following five lines draw matrix plots for all indices vs. yield in both conditions
pairs(~y.nrm+y.str+YR+SSI+TOL,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+STI+MpSTI+MsSTI,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+ATI+YI+YSI,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+MP+GMP+HARM+GM,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+SDI+SSPI+RDI+DI,data=i, main="Scatterplot Matrix")


#This section performs 3D plot for indicated indices in the pic
s3d <- with(i, scatterplot3d(y.nrm, y.str, TOL, highlight.3d=TRUE, pch="", type="h",
                      xlab="Yield in normal condition", 
                      ylab="stress", 
                      zlab="TOL",
                      main="TOL vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$TOL), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(y.nrm, y.str, GMP, highlight.3d=TRUE, pch="", type="h",
                      xlab="Yield in normal condition", 
                      ylab="stress", 
                      zlab="GMP",
                      main="GMP vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$GMP), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(y.nrm, y.str, SSI, highlight.3d=TRUE, pch="", type="h",
                      xlab="Yield in normal condition", 
                      ylab="stress", 
                      zlab="SSI",
                      main="SSI vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$SSI), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(y.nrm, y.str, STI, highlight.3d=TRUE, pch="", type="h",
                      xlab="Yield in normal condition", 
                      ylab="stress", 
                      zlab="STI",
                      main="STI vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$STI), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(MpSTI, MsSTI, STI, highlight.3d=TRUE, pch="", type="h",
                      xlab="MpSTI", 
                      ylab="MsSTI", 
                      zlab="STI",
                      main="STI vs. MpSTI vs. MsSTI"))
text(s3d$xyz.convert(i$MpSTI, i$MsSTI, i$STI), labels = rownames(i),
     cex= 1.3, col = "blue")



#Following code depicts the heatmap analysis for genotypes vs. indices
matrix <- as.matrix(i)
rownames(matrix) <- dt[,1]
matc.scl <- scale(matrix) #normalizes the data and removes the units
heatmap.2(matc.scl, margins = c(6, 8))


#Following performs principal component analysis and depict scree plot, individual
#plot of genotypes in a 2d sheet, loading plot of the indices in a 2d shett and
#biplot for all indices vs. all genotypes in a 2d sheet 
pca <- prcomp(i, scale = TRUE)
fviz_eig(pca)
fviz_pca_ind(pca, col.ind = "cos2", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), repel = TRUE)
fviz_pca_var(pca, col.var = "contrib", 
             gradient.cols = c("#00AFBB", "#E7B800", "#FC4E07"), repel = TRUE)
fviz_pca_biplot(pca, col.var = "blue", col.ind = "black", repel = TRUE,)


#This section provide a data table named "y" showing first and second components 
#values for all used genotypes
cl <- as.matrix(pca$rotation); x <- cl[, 1:2]
x <- as.data.frame(x) #View(x)
gn <- as.matrix(pca$x); gen.pc.12 <- gn[, 1:2]; 
rownames(gen.pc.12) <- rownames(i) 
#View(gen.pc.12)
y <- cbind.data.frame(gen.pc.12, i[ , 1:2])
#View(y)


#Following code determines the tope 20 percent genotypes in each condition and 
#add the results to "y" data table showing suitable genotypes for these conditions
mn=mean(i$y.nrm);sn=sqrt(var(df$p)/length(df$p))
qn <- mn+(1.63*sn); qnn <- as.matrix(rep(qn, nrow(y)))
ms=mean(i$y.str);ss=sqrt(var(df$s)/length(df$s))
qs <- ms+(1.63*ss); qss <- as.matrix(rep(qs, length(y$y.nrm)))
y <- cbind.data.frame(y, qnn, qss)

normal = 1:nrow(y)
for (j in 1:nrow(y)){
  if (y$y.nrm[j] >= y$qnn[j]) {
    y$normal[j]<-paste("Genotype number", j, 
                       "is probably proper for normal condition", sep=" ") } 
  else {y$normal[j]<- "NOT proper"}
}

stress = 1:nrow(y)
for (j in 1:nrow(y)){
  if (y$y.str[j] >= y$qss[j]) {
    y$stress[j]<-paste("Genotype number", j, 
                       "is propper for stress condition", sep=" ") } 
  else {y$stress[j]<- "NOT proper"}
}



#this section tries to find any genotype that is proper for both conditions based 
#the results from PCA. If the sign of yield in stress and normal conditions are
#simialr, "Null" would print in the "y" data table, otherwise, would show proper
#genotypes based on the row number of each genotype
y$sgn1 <- 1:nrow(y)
for (j in 1:nrow(y))
{y$sgn1[j] = sign(y$PC1[j])
}

y$sgn2 <- 1:nrow(y)
for (j in 1:nrow(y))
{y$sgn2[j] = sign(y$PC2[j])
}

x$pc1_sgn <- 1:nrow(x)
for (j in 1:nrow(x))
{x$pc1_sgn[j] = sign(x[j, 1])
}

x$pc2_sgn <- 1:nrow(x)
for (j in 1:nrow(x))
{x$pc2_sgn[j] = sign(x$PC2[j])
}

yy <- y[, 9:10]
#View(yy)

yy$nrmpc1 <- x[1, 3]
yy$strpc1 <- x[2, 3]
yy$nrmpc2 <- x[1, 4]
yy$strpc2 <- x[2, 4]

yy$both <- 1:nrow(yy)
if(yy[1,3] == yy[1,4] & yy[1,5] == yy[1,6]){ 
  for (z in 1:nrow(yy)) {
    if(yy[z,1] == yy[z,3] & yy[z,2] == yy[z,5]){
      yy$both[z] <- paste("GENOTYPE number", z, "is PROPPER",
                            "for both normal and stress conditions",
                            sep=" ")
    }
    else {yy$both[z] <- "NOT for both"}
  }
} else{yy$both <- "Null"}

y <- cbind.data.frame(y[, -c(5:6, 9:10)], yy$both) 
View(y)
x <- x[, -c(3:4)]
View(x)

#This section writes the output results of all created dataset in
#the directory that are indicated for the software. 
#Hear, we import them into "desktop"Document" folder (W10)
dir1 <- paste(getwd(), "/Indices.csv", sep ="")
dir2 <- paste(getwd(), "/PCA_Genotypes.csv", sep ="")
dir3 <- paste(getwd(), "/PCA_Indices.csv", sep ="")
dir4 <- paste(getwd(), "/Correlation_Indices.csv", sep ="")
write.csv(i, dir1)
write.csv(y, dir2)
write.csv(x, dir3)
write.csv(corr, dir4)

##Follwoing code would help users to find the directory of their output results
paste("The output results are stred in", getwd(), sep= "-----------
        --------------------------------->  ")

}
