
#' Depicting scatter plot and scatter matrices related to yiled and tollerance indices 
#'
#' Depicting scatter plot and scatter matrices related to yiled and tollerance indices.
#' #' @param scattermatrix data should be provided.
#' @return matrix of scatter plots.
#' @export
#' @examples
#' scattermatrix()
#' 
scattermatrix <- function(){

#This section loads the packages that are used for analysis
library(readxl) #for reading excel files
require(gplots) #drawing instrument for related packages 
require(ggplot2) #drawing instrument for related packages
require(factoextra) #calculating principal component analysis based on indices
require(ggcorrplot) #for drawing correlation plot 
require(scatterplot3d) #for drawing 3D plots 

#This section is for loading excel sheet containing data
df <- read_excel(file.choose(), sheet = 1); df <- df[, 1:4]  
colnames(df) <- c("genotype", "replications", "p", "s")
df <- df[order(df$genotype),]  
#View(df)

#This section calculates the mean yield of each genotype and sort them accordingly
attach(df) 
dt <- aggregate(df, by=list(genotype), FUN=mean, na.rm=TRUE)
dt <- dt[order(dt$genotype),]
dt <- as.data.frame(dt[, -c(1, 3)])
#View(dt)

m.p <- mean(dt$p); m.s <- mean(dt$s) #Calculates total mean yield in each condition

#This section calculated the tollerance indices based on their formulas
SSI <- (1-(dt$s/dt$p))/(1-(dt$s/m.p))
SSI <- as.matrix(SSI); colnames(SSI)<- "SSI"

YR <- 1-(dt$s/dt$p)
YR <- as.matrix(YR); colnames(YR)<- "YR"

TOL <- dt$p-dt$s
TOL <- as.matrix(TOL); colnames(TOL)<- "TOL"

MP <- (dt$s+dt$p)/2
MP <- as.matrix(MP); colnames(MP)<- "MP"

YI <- dt$s/m.s
YI <- as.matrix(YI); colnames(YI)<- "YI"

YSI <- dt$s/dt$p
YSI <- as.matrix(YSI); colnames(YSI)<- "YSI"

GMP <- (dt$s*dt$p)^0.5
GMP <- as.matrix(GMP); colnames(GMP)<- "GMP"

HARM <- (2*dt$p*dt$s)/(dt$p+dt$s)
HARM <- as.matrix(HARM); colnames(HARM)<- "HARM"

STI <- (dt$p*dt$s)/(dt$p^2)
STI <- as.matrix(STI); colnames(STI)<- "STI"

MpSTI <- ((dt$p*2)/(m.p*2))*((dt$p*dt$s)/(dt$p^2))
MpSTI <- as.matrix(MpSTI); colnames(MpSTI)<- "MpSTI"

MsSTI <- ((dt$s*2)/(m.s*2))*((dt$p*dt$s)/(dt$p^2))
MsSTI <- as.matrix(MsSTI); colnames(MsSTI)<- "MsSTI"

SDI <- (dt$p-dt$s)/dt$p
SDI <- as.matrix(SDI); colnames(SDI)<- "SDI"

SSPI <- ((dt$p-dt$s)/(2*m.p))*100
SSPI <- as.matrix(SSPI); colnames(SSPI)<- "SSPI"

RDI <- (dt$s/dt$p)/(m.s/m.p)
RDI <- as.matrix(RDI); colnames(RDI)<- "RDI"

DI <- ((dt$s/dt$p)/m.s)*dt$s
DI <- as.matrix(DI); colnames(DI)<- "DI"

ATI <- ((dt$p-dt$s)/(m.p-m.s))*((dt$p*dt$s)^0.5)
ATI <- as.matrix(ATI); colnames(ATI)<- "ATI"

GM <- (dt$p*dt$s)/(dt$p-dt$s)
GM <- as.matrix(GM); colnames(GM)<- "GM"


#Following lines (87-93) provides a data table named "i" containing all calculated indices
i <- cbind(dt$p, dt$s, YR, SSI, TOL, STI, MpSTI, MsSTI, ATI, YI, 
           YSI, MP, GMP, HARM, GM, SDI, SSPI, RDI, DI)
colnames(i) <- c('y.nrm', 'y.str', 'YR', 'SSI', 'TOL', 'STI', 'MpSTI',
                 'MsSTI','ATI', 'YI', 'YSI','MP', 'GMP', 'HARM', 'GM',
                 'SDI', 'SSPI', 'RDI', 'DI')
rownames(i) <- dt[,1]; i <- as.data.frame(i)
#View(i)


#Following code section performs scater plot for yield in stress vs. normal
with(i, plot(y.nrm, y.str, main="Yield: stress vs. normal",
             xlab="Yield in normal condition", 
             ylab="Yield in stress condition", pch=15, col="red"))
abline(a = mean(i$y.str), b = 0, v = mean(i$y.nrm), col="blue")


#Following five lines draw matrix plots for all indices vs. yield in both conditions
pairs(~y.nrm+y.str+YR+SSI+TOL,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+STI+MpSTI+MsSTI,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+ATI+YI+YSI,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+MP+GMP+HARM+GM,data=i, main="Scatterplot Matrix")
pairs(~y.nrm+y.str+SDI+SSPI+RDI+DI,data=i, main="Scatterplot Matrix")


}