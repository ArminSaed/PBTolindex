
#' Depicting 3D plot related to yiled and tollerance indices 
#'
#' Depicting 3D plots related to yiled and tollerance indices.
#' #' @param threeD data should be provided.
#' @return 3d plots.
#' @export
#' @examples
#' threeD()
#'

threeD <- function(){

#This section loads the packages that are used for analysis
library(readxl) #for reading excel files
require(gplots) #drawing instrument for related packages 
require(ggplot2) #drawing instrument for related packages
require(factoextra) #calculating principal component analysis based on indices
require(ggcorrplot) #for drawing correlation plot 
require(scatterplot3d) #for drawing 3D plots 

#This section is for loading excel sheet containing data
df <- read_excel(file.choose(), sheet = 1); df <- df[, 1:4]  
colnames(df) <- c("genotype", "replications", "p", "s")
df <- df[order(df$genotype),]  
#View(df)

#This section calculates the mean yield of each genotype and sort them accordingly
attach(df) 
dt <- aggregate(df, by=list(genotype), FUN=mean, na.rm=TRUE)
dt <- dt[order(dt$genotype),]
dt <- as.data.frame(dt[, -c(1, 3)])
#View(dt)

m.p <- mean(dt$p); m.s <- mean(dt$s) #Calculates total mean yield in each condition

#This section calculated the tollerance indices based on their formulas
SSI <- (1-(dt$s/dt$p))/(1-(dt$s/m.p))
SSI <- as.matrix(SSI); colnames(SSI)<- "SSI"

YR <- 1-(dt$s/dt$p)
YR <- as.matrix(YR); colnames(YR)<- "YR"

TOL <- dt$p-dt$s
TOL <- as.matrix(TOL); colnames(TOL)<- "TOL"

MP <- (dt$s+dt$p)/2
MP <- as.matrix(MP); colnames(MP)<- "MP"

YI <- dt$s/m.s
YI <- as.matrix(YI); colnames(YI)<- "YI"

YSI <- dt$s/dt$p
YSI <- as.matrix(YSI); colnames(YSI)<- "YSI"

GMP <- (dt$s*dt$p)^0.5
GMP <- as.matrix(GMP); colnames(GMP)<- "GMP"

HARM <- (2*dt$p*dt$s)/(dt$p+dt$s)
HARM <- as.matrix(HARM); colnames(HARM)<- "HARM"

STI <- (dt$p*dt$s)/(dt$p^2)
STI <- as.matrix(STI); colnames(STI)<- "STI"

MpSTI <- ((dt$p*2)/(m.p*2))*((dt$p*dt$s)/(dt$p^2))
MpSTI <- as.matrix(MpSTI); colnames(MpSTI)<- "MpSTI"

MsSTI <- ((dt$s*2)/(m.s*2))*((dt$p*dt$s)/(dt$p^2))
MsSTI <- as.matrix(MsSTI); colnames(MsSTI)<- "MsSTI"

SDI <- (dt$p-dt$s)/dt$p
SDI <- as.matrix(SDI); colnames(SDI)<- "SDI"

SSPI <- ((dt$p-dt$s)/(2*m.p))*100
SSPI <- as.matrix(SSPI); colnames(SSPI)<- "SSPI"

RDI <- (dt$s/dt$p)/(m.s/m.p)
RDI <- as.matrix(RDI); colnames(RDI)<- "RDI"

DI <- ((dt$s/dt$p)/m.s)*dt$s
DI <- as.matrix(DI); colnames(DI)<- "DI"

ATI <- ((dt$p-dt$s)/(m.p-m.s))*((dt$p*dt$s)^0.5)
ATI <- as.matrix(ATI); colnames(ATI)<- "ATI"

GM <- (dt$p*dt$s)/(dt$p-dt$s)
GM <- as.matrix(GM); colnames(GM)<- "GM"


#Following lines (87-93) provides a data table named "i" containing all calculated indices
i <- cbind(dt$p, dt$s, YR, SSI, TOL, STI, MpSTI, MsSTI, ATI, YI, 
           YSI, MP, GMP, HARM, GM, SDI, SSPI, RDI, DI)
colnames(i) <- c('y.nrm', 'y.str', 'YR', 'SSI', 'TOL', 'STI', 'MpSTI',
                 'MsSTI','ATI', 'YI', 'YSI','MP', 'GMP', 'HARM', 'GM',
                 'SDI', 'SSPI', 'RDI', 'DI')
rownames(i) <- dt[,1]; i <- as.data.frame(i)
#View(i)


#This section performs 3D plot for indicated indices in the pic
s3d <- with(i, scatterplot3d(y.nrm, y.str, TOL, highlight.3d=TRUE, pch="", type="h",
                             xlab="Yield in normal condition", 
                             ylab="stress", 
                             zlab="TOL",
                             main="TOL vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$TOL), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(y.nrm, y.str, GMP, highlight.3d=TRUE, pch="", type="h",
                             xlab="Yield in normal condition", 
                             ylab="stress", 
                             zlab="GMP",
                             main="GMP vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$GMP), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(y.nrm, y.str, SSI, highlight.3d=TRUE, pch="", type="h",
                             xlab="Yield in normal condition", 
                             ylab="stress", 
                             zlab="SSI",
                             main="SSI vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$SSI), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(y.nrm, y.str, STI, highlight.3d=TRUE, pch="", type="h",
                             xlab="Yield in normal condition", 
                             ylab="stress", 
                             zlab="STI",
                             main="STI vs. normal vs. stress"))
text(s3d$xyz.convert(i$y.nrm, i$y.str, i$STI), labels = rownames(i),
     cex= 1.0, col = "blue")

s3d <- with(i, scatterplot3d(MpSTI, MsSTI, STI, highlight.3d=TRUE, pch="", type="h",
                             xlab="MpSTI", 
                             ylab="MsSTI", 
                             zlab="STI",
                             main="STI vs. MpSTI vs. MsSTI"))
text(s3d$xyz.convert(i$MpSTI, i$MsSTI, i$STI), labels = rownames(i),
     cex= 1.3, col = "blue")
}
